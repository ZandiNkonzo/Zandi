# mypackage
This package was created for the purposes of writing reusable code for sorting and recursion of arrays

## installing this package from github
pip install git+https://github.com/Zandi-macnkonzo/

##updating this package from github
pip install --upgrade git+https://github.com/Zandi-macnkonzo/
